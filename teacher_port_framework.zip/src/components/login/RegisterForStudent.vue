<template>
<div class="studentRegister">
  <el-button type="primary" @click="signup">学生注册</el-button>
</div>
</template>

<script>
    export default {
        name: "RegisterForStudent",
      methods:{
          signup(){
            this.$router.push('/home');
          }
      }
    }
</script>

<style scoped>
.studentRegister{
  position:absolute;
  left:400px;
  top:200px
}
</style>
