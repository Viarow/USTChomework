<template>
  <p>暂时没有班级文件</p>
</template>

<script>
    export default {
        name: "ClassFiles"
    }
</script>

<style scoped>

</style>
