import Vue from 'vue'
import Router from 'vue-router'
//import HelloWorld from '@/components/HelloWorld'
import Frame from '@/components/frame'
import StudentList from '@/components/student/student-list'
import StudentAdd from '@/components/student/student-add'
import LoginForm from '@/components/login/LoginForm'
import RegisterForTeacher from '@/components/login/RegisterForTeacher'
import RegisterForStudent from '@/components/login/RegisterForStudent'


Vue.use(Router)

export default new Router({
  routes: [
      {
          path: '/login/LoginForm',
          component: LoginForm
      },
    {
      path: '/Register/student',
      component: RegisterForStudent
    },
    {
      path: '/Register/teacher',
      component: RegisterForTeacher
    }

  ]
})
