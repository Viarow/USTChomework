<!-- 展示模板 -->
<template>
  <div id="app">
    <!--<img src="./assets/logo.png">-->
    <LoginForm></LoginForm>
    <router-view></router-view>

  </div>
</template>

<script>
// 导入组件
//import Hello from './components/HelloWorld'
import Frame from './components/frame'
import StudentAdd from './components/student/student-add'
import StudentList from './components/student/student-list'
import LoginForm from './components/login/LoginForm'
import RegisterForTeacher from './components/login/RegisterForTeacher'
import RegisterForStudent from './components/login/RegisterForStudent'

export default {
  name: 'app',
  components: {
    LoginForm,RegisterForStudent,RegisterForTeacher
  }
}
</script>
<!-- 样式代码 -->
<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
