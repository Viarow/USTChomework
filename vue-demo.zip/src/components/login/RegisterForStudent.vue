<template>
  <el-button type="primary">学生注册</el-button>
</template>

<script>
    export default {
        name: "RegisterForStudent"
    }
</script>

<style scoped>

</style>
