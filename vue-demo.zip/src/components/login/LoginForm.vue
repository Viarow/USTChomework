<template>

   <div id="LoginForm">
    <el-form ref="form" :model="form" label-width="80px" >

    <el-form-item label="登录邮箱">
      <el-input  v-model="loginEmail" class="input-with-select">
        <el-select v-model="select" slot="append" >
          <el-option label="@mail.ustc.edu.cn" value="1"></el-option>
          <el-option label="@ustc.edu.cn" value="2"></el-option>
        </el-select>
      </el-input>
    </el-form-item>

    <el-form-item label="登录密码">
      <el-input  v-model="loginPassword" maxlength=20 >
        <el-button slot="append" type="danger">忘记密码</el-button>
      </el-input>
    </el-form-item>

    <el-form-item>
      <el-button type="primary" @click="login">登录</el-button>
      <el-button-group>
        <el-button type="primary" command='teacher' @click="register" >教师注册</el-button>
        <el-button type="primary" command='student' @click="register">学生注册</el-button>
      </el-button-group>
    </el-form-item>

  </el-form>
  </div>

</template>

<script>
    export default {
      name: "LoginForm",
      data() {
        return {
          activeIndex: '',
          form: {
            loginEmail: '',
            loginPassword: '',
            select: ''
          }
        }
      },

      methods: {
        login() {
          console.log('登陆成功！');
        },
        register(command){
          if(command=='teacher'){
            this.$router.push('/Register/teacher');
          }else if(command=='student'){
            this.$router.push('/Register/student');
          }
        }
      }

    }
</script>

<style scoped>

</style>
