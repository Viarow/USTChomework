<template>
  <el-button type="primary">教师注册</el-button>
</template>

<script>
    export default {
        name: "RegisterForTeacher"
    }
</script>

<style scoped>

</style>
